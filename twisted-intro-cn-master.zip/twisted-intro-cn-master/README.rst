================================================================================
Dave's An Introduction to Asynchronous Programming and Twisted in Chinese
================================================================================
本项目是"Twisted与异步编程入门"系列文章的简体中文翻译.
原文由Dave撰写，参见 `krondo.com <http://krondo.com/blog/?page_id=1327>`_. 

如果您是Twisted新手, `Twisted 文档`_ 也是不错的选择.  

This is a translation project of "An Introduction to Asynchronous Programming and Twisted" in Chinese.
The original materials are `krondo.com <http://krondo.com/blog/?page_id=1327>`_. 

If you are new to Twisted, `Twisted Documentation`_ is a good starting point.

.. _Twisted 文档: http://twistedmatrix.com/documents/10.0.0/core/howto/index.html

.. _Twisted Documentation: http://twistedmatrix.com/documents/10.0.0/core/howto/index.html
